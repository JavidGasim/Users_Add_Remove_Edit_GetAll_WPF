﻿using System.Windows.Navigation;

namespace WpfApp6
{
    public partial class MainWindow : NavigationWindow
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
