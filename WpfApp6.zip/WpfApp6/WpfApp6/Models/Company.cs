﻿namespace WpfApp6.Models;

public class Company
{
    public string name { get; set; }
    public string bs { get; set; }
}
