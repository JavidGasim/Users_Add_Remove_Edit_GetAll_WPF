﻿namespace WpfApp6.Models;

public class Address
{
    public string street { get; set; }
    public string city { get; set; }

}
