﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Text.Json;
using System.Windows.Controls;
using WpfApp6.Models;

namespace WpfApp6.Views.Pages
{
    public partial class GetAllPage : Page, INotifyPropertyChanged
    {
        private ObservableCollection<User> users;

        //public ObservableCollection<User> Users { get => users; set => users = value; }
        public GetAllPage()
        {
            InitializeComponent();

            var folder = new DirectoryInfo("../../../DataBase");
            var fullPath = Path.Combine(folder.FullName, "Users.json");

            var JsonText = File.ReadAllText(fullPath);
            var users = JsonSerializer.Deserialize<ObservableCollection<User>>(JsonText);
        }

        public event PropertyChangedEventHandler? PropertyChanged;
    }
}
