﻿using Microsoft.VisualBasic;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Reflection.Metadata;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Windows.Controls;
using System.Windows.Input;
using WpfApp6.Commands;
using WpfApp6.Models;
using WpfApp6.Views.Pages;
using WpfApp6.Views.Windows;

namespace WpfApp6.ViewModels.PageViewModels
{
    public class MainPageViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<User> users;

        public ObservableCollection<User> Users
        {
            get { return users; }
            set { users = value; OnPropertyChanged(); }
        }

        public ICommand RemoveCommand { get; set; }
        public ICommand GetAllCommand { get; set; }
        public ICommand AddCommand { get; set; }
        public ICommand EditCommand { get; set; }

        public MainPageViewModel()
        {
            var fullPath = "../../../DataBase/Users.json";

            var JsonText = File.ReadAllText(fullPath);
            var users2 = JsonSerializer.Deserialize<ObservableCollection<User>>(JsonText);

            Users = users2;

            AddCommand = new RelayCommand(AddElement);
            RemoveCommand = new RelayCommand(RemoveElement, CanRemove);
            EditCommand = new RelayCommand(EditElement, CanEditElement);
            GetAllCommand = new RelayCommand(GetAll);
        }

        public void AddElement(object? parametr)
        {
            var page2 = parametr as Page;

            if (page2 != null)
            {
                var page = new AddPage();
                page.DataContext = new AddViewModel(Users);
                page2.NavigationService.Navigate(page);
            }
        }

        public void EditElement(object? parameter)
        {
            User newUser = Users[(int)parameter];
            EditView? editView = new EditView();
            editView!.DataContext = new EditViewModel(newUser);
            editView.ShowDialog();

            var fullPath = "../../../DataBase/Users.json";

            var json = JsonSerializer.Serialize<ObservableCollection<User>>(Users);
            File.WriteAllText(fullPath, json);
        }

        public bool CanEditElement(object? parameter)
        {
            var param = (int)parameter;
            return param != -1;
        }

        public void RemoveElement(object? parametr)
        {


            int index = Convert.ToInt32(parametr);
            Users.RemoveAt(index);

            var folder = new DirectoryInfo("../../../Database");
            var fullPath = Path.Combine(folder.FullName, "User.json");

            var json = JsonSerializer.Serialize<ObservableCollection<User>>(Users);
            File.WriteAllText(fullPath, json);

        }

        public bool CanRemove(object? parametr)
        {

            if (parametr != null)
            {
                int index = Convert.ToInt32(parametr);
                if (index != -1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }
        public void GetAll(object? parametr)
        {
            var page2 = parametr as Page;

            if (page2 != null)
            {
                var page = new GetAllPage();
                page.DataContext = new GetAllViewModel(Users);
                page2.NavigationService.Navigate(page);
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}